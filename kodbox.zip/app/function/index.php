<?php
// 用于检测功能;
if(isset($_GET['sitemap/urlType'])){echo '[ok]';exit;}
?>